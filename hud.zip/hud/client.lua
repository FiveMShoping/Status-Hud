local ESX = nil
local characterName = nil
local hudVisible = true 


Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        if not ESX then
            TriggerEvent('esx:getSharedObject', function(obj)
                ESX = obj
            end)
        end
        Citizen.Wait(0)
    end

    while not ESX.GetPlayerData() or not ESX.GetPlayerData().job do
        Citizen.Wait(100)
    end

    local playerData = ESX.GetPlayerData()
    if playerData then
        if playerData.firstName and playerData.lastName then
            characterName = playerData.firstName .. ' ' .. playerData.lastName
        elseif playerData.firstname and playerData.lastname then
            characterName = playerData.firstname .. ' ' .. playerData.lastname
        else
            characterName = GetPlayerName(PlayerId())
        end
    end
end)



RegisterCommand('toggleHud', function()
    hudVisible = not hudVisible 

    SendNUIMessage({
        type = 'toggleHud',
        visible = hudVisible
    })

    if hudVisible then
        ESX.ShowNotification("HUD ~g~bekapcsolva")
    else
        ESX.ShowNotification("HUD ~r~kikapcsolva")
    end
end, false)

RegisterKeyMapping('toggleHud', 'HUD Ki/Be Kapcsolása', 'keyboard', 'F10')

  

local function getPlayerStatuses(callback)
    local statusData = { hunger = 100, thirst = 100 } 
    local count = 0
    local total = 2

    TriggerEvent('esx_status:getStatus', 'hunger', function(hungerStatus)
        if hungerStatus then
            statusData.hunger = math.floor(hungerStatus.getPercent())
        end
        count = count + 1
        if count == total then
            callback(statusData)
        end
    end)

    TriggerEvent('esx_status:getStatus', 'thirst', function(thirstStatus)
        if thirstStatus then
            statusData.thirst = math.floor(thirstStatus.getPercent())
        end
        count = count + 1
        if count == total then
            callback(statusData)
        end
    end)
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)

        local playerPed = PlayerPedId()
        local playerId  = PlayerId()
        local serverId  = GetPlayerServerId(playerId)

        local rawHealth = GetEntityHealth(playerPed)
        local health = (rawHealth > 100) and (rawHealth - 100) or 0
        local armour = GetPedArmour(playerPed)

        local playerData = ESX.GetPlayerData()
        local money = 0
        local bank  = 0

        
        if playerData.accounts then
            for _, account in pairs(playerData.accounts) do
                if account.name == 'money' then
                    money = account.money
                elseif account.name == 'bank' then
                    bank = account.money
                end
            end
        end

        local job = (playerData.job and playerData.job.label) or 'N/A'

        getPlayerStatuses(function(statuses)
            SendNUIMessage({
                type       = 'updateStatus',
                playerName = characterName or 'Betöltés...',
                serverId   = serverId,
                hunger     = statuses.hunger,
                thirst     = statuses.thirst,
                health     = health,
                armour     = armour,
                money      = money,
                bank       = bank,
                job        = job
            })
        end)
    end
end)
