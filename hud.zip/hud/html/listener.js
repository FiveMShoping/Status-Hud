
window.addEventListener('message', (event) => {
  const data = event.data;

  if (data.type === 'toggleHud') {
      const hudContainer = document.getElementById('hudContainer');
      if (data.visible) {
          hudContainer.style.display = 'flex'; 
      } else {
          hudContainer.style.display = 'none'; 
      }
  }
});

let previousMoney = null;

function animateNumberChange(element, start, end, duration = 1000) {
  const startTime = performance.now();
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const value = Math.floor(start + (end - start) * progress);
    element.textContent = value;
    if (progress < 1) {
      requestAnimationFrame(update);
    } else {
      element.textContent = end;
    }
  }
  
  requestAnimationFrame(update);
}

function showMoneyChangeIndicator(change) {
  const container = document.querySelector('.moneyContainer');
  const indicator = document.createElement('div');
  indicator.classList.add('moneyChangeIndicator');
  indicator.classList.add(change >= 0 ? 'positive' : 'negative');
  indicator.textContent = (change >= 0 ? '+' : '') + change;
  
  container.appendChild(indicator);
  
  setTimeout(() => {
    indicator.remove();
  }, 1500);
}

window.addEventListener('message', (event) => {
  const data = event.data;
  
  if (data.type === 'updateStatus') {
   
      document.getElementById('playerName').textContent = data.playerName;
    document.getElementById('serverId').textContent   = data.serverId;
    
    const moneyElement = document.getElementById('moneyValue');
    const newMoney = Number(data.money); 
    if (previousMoney === null) {
      previousMoney = newMoney;
      moneyElement.textContent = newMoney;
    } else if (newMoney !== previousMoney) {
      const change = newMoney - previousMoney;
      showMoneyChangeIndicator(change);
      animateNumberChange(moneyElement, previousMoney, newMoney);
      previousMoney = newMoney;
    }
    
    document.getElementById('bankValue').textContent = data.bank;
    document.getElementById('jobValue').textContent  = data.job;
    document.getElementById('hungerValue').textContent = Math.floor(data.hunger);
    document.getElementById('thirstValue').textContent = Math.floor(data.thirst);
    document.getElementById('healthValue').textContent = data.health;
    document.getElementById('armourValue').textContent = data.armour;
    document.getElementById('hungerBar').style.width = data.hunger + '%';
    document.getElementById('thirstBar').style.width = data.thirst + '%';
    document.getElementById('healthBar').style.width = (data.health > 100 ? 100 : data.health) + '%';
    document.getElementById('armourBar').style.width = (data.armour > 100 ? 100 : data.armour) + '%';
  }
});
