fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'FiveM Shop'
description 'Simple Status HUD for ESX '
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/listener.js'
}

client_scripts {
    'client.lua'
}

